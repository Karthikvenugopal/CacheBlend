# Closed research direction

The user closed and archived this direction. Preserve its implementation, raw results, failed runs, input caveats and negative findings.

No budget expansion, additional case search, selector development or other experiment is authorized by the retained historical instructions. Do not resume work unless the user explicitly reopens it.

This is internal learning work. Do not use it in resumes or outreach. Do not present it as a successful repair method, a novelty claim or a demonstrated performance improvement.

Read `docs/closure.md` for the final assessment and archive location. Historical reproduction commands are reference material, not requests to execute them.
